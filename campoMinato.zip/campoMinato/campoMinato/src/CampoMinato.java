import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CampoMinato implements ActionListener {
    static int righe = 14;
    static int colonne = 18;
    static Casella[][] caselle = new Casella[righe][colonne];
    static JTextField jT; //mostra la riga e la colonna cliccatta

    ImageIcon iconaChiara, iconaScura;
    ImageIcon iconaHover;
    ImageIcon iconaClick;

    public static void main(String[] args) {
        new CampoMinato();
    }

    public CampoMinato() {
        int larg = 1200;
        int alt = 1200;
        JFrame f = new JFrame("Campo Minato");
        f.setBounds(100, 100, larg, alt);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLayout(null);

        JPanel p = new JPanel();
        p.setBounds(70, 0, larg - 150, alt - 150);
        p.setLayout(new GridLayout(righe, colonne));

        int larghezzaCasella = (larg - 150) / colonne;
        int altezzaCasella = (alt - 150) / righe;

        // Carica immagini
        iconaChiara = scalaIcona("campoMinato/campoC.jpeg", larghezzaCasella, altezzaCasella);
        iconaScura = scalaIcona("campoMinato/campo.png", larghezzaCasella, altezzaCasella);
        iconaHover = scalaIcona("campoMinato/campoC+.jpeg", larghezzaCasella, altezzaCasella);
        iconaClick = scalaIcona("campoMinato/campoC_click.jpeg", larghezzaCasella, altezzaCasella);

        // Crea le caselle
        for (int k = 0; k < righe; k++) {
            for (int j = 0; j < colonne; j++) {
                // Determina se la casella è chiara o scura in base alla somma di k e j
                boolean casellaChiara;
                if ((k + j) % 2 == 0) {
                    casellaChiara = true; // Casella chiara
                } else {
                    casellaChiara = false; // Casella scura
                }

                // Scegli l'icona per la casella in base a se è chiara o scura
                ImageIcon iconaCasellaNormale;
                ImageIcon iconaCasellaHover = iconaHover;
                if (casellaChiara) {
                    iconaCasellaNormale = iconaChiara;
                } else {
                    iconaCasellaNormale = iconaScura;
                }

                // Crea una nuova casella e imposta le sue proprietà
                Casella casella = new Casella(false, 0, iconaCasellaNormale, iconaCasellaHover);
                casella.setChiara(casellaChiara);  // Imposta se la casella è chiara o scura
                casella.addActionListener(this);   // Aggiungi un ascoltatore per gli eventi

                // Aggiungi la casella al contenitore 'p' e memorizzala nell'array 'caselle'
                p.add(casella);
                caselle[k][j] = casella;
            }
        }

// Aggiungi il contenitore 'p' al frame
        f.add(p);

// Crea un campo di testo e impostane le dimensioni
        jT = new JTextField();
        jT.setBounds(100, alt - 130, 200, 40);
        f.add(jT);

// Rendi visibile la finestra
        f.setVisible(true);
    }

    private ImageIcon scalaIcona(String path, int larghezza, int altezza) {
        ImageIcon icona = new ImageIcon(path);
        Image img = icona.getImage().getScaledInstance(larghezza, altezza, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object sorgente = e.getSource();

        for (int k = 0; k < righe; k++) {
            for (int j = 0; j < colonne; j++) {
                Casella c = caselle[k][j];
                if (sorgente.equals(c) && !c.isCliccata()) {
                    c.setCliccata(true);
                    jT.setText("Riga: " + k + "    Colonna: " + j);
                    c.setIcon(iconaClick);
                    //blocca ulteriori click
                    c.removeActionListener(this);
                }
            }
        }
    }
}



//.........................................................................

